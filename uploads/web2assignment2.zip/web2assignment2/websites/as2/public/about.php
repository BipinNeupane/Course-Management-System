<?php
$title = "jojo's  -about";

?>
	<?php
    $content = '<main class="home">
    <p>Welcome to Jo\'s Jobs, we\'re a recruitment agency based in Northampton. We offer a range of different office jobs. Get in touch if you\'d like to list a job with us.</a></p>

    <h2>Select the type of job you are looking for:</h2>
    <ul>
        <?php require\'admin/category-list-template.php\';?>
    </ul>
    </li>

</main>';

?>
<!--
This code sets two variables: $title and $content. $title contains a string with the title of the webpage. $content contains HTML markup, as well as a PHP block that uses the  tags to require the 'category-list-template.php' file.

The 'category-list-template.php' file is likely to contain a template for a list of job categories, which will be included on the page when it is loaded.

Overall, this code appears to be setting up the content of an "about" page for a recruitment agency website. The inclusion of the job category list suggests that the agency offers a range of different job types.
-->
<!--
This code sets two variables: $title and $content. $title contains a string with the title of the webpage. $content contains HTML markup, as well as a PHP block that uses the tags to require the 'category-list-template.php' file.

The 'category-list-template.php' file is likely to contain a template for a list of job categories, which will be included on the page when it is loaded.

Overall, this code appears to be setting up the content of an "about" page for a recruitment agency website. The inclusion of the job category list suggests that the agency offers a range of different job types.
-->
