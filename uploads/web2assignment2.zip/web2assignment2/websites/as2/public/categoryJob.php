<?php
$title = "Jo's Jobs - IT Jobs";
//hiding errors
error_reporting(0);
//getting catId
$catId = $_GET['catId'];

$c1 = "<?php require'admin/category-list-template.php'?>";
$c2 ='<?php 
$location = $_GET["location"];
if ($catId !=\'\'){
    $names = selectFromTable(\'category\', \'name\', [\'id\' => $catId]);
    foreach($names as $name){
        $catName = $name[\'name\'];
    } 
    echo \'<h1>\'. $catName.\' Jobs</h1>\';
}
elseif($location != \'\'){
    echo \'<h1>\'.$location.\' jobs </h1>\';
}
?>';
$c3 = '<?php 
$catId = $_GET[\'catId\'];
$location = $_GET["location"];
if ($catId !=\'\'){
$stmt = selectFromTable(\'job\', \'*\', [\'status\' => 1, \'categoryId\' => $catId, \'closingDate\' => [\'>\', date(\'Y-m-d\')]], \'\', \'\');
foreach($stmt as $job){
	  $j = $job[\'title\'];
	  $s = $job[\'salary\'];
	  $d = $job[\'description\'];
	  $i = $job[\'id\'];
	  toDisplayCategorisedJob($j,$s,$d,$i);
}
}elseif($location != \'\'){
$stmt = selectFromTable(\'job\', \'*\', [\'status\' => 1, \'location\' => $location, \'closingDate\' => [\'>\', date(\'Y-m-d\')]], \'\', \'\');
foreach($stmt as $job){
	$j = $job[\'title\'];
	$s = $job[\'salary\'];
	$d = $job[\'description\'];
	$i = $job[\'id\'];
	toDisplayCategorisedJob($j,$s,$d,$i);
}
}?>';
$content = '<?php
$template = include("categoryJob-template.php");
?>';

 
?>


<!--This code is defining variables and building a dynamic PHP page that displays job listings based on either a category or location. The variables include:

$title: a string that sets the title of the webpage
$catId: a variable that retrieves the category ID from the URL parameter catId
$c1, $c2, $c3, and $content: strings that contain PHP code, which is later included in the main PHP script to generate the page.
The code is using the selectFromTable function to retrieve job listings from a database based on the category ID or location provided. The retrieved data is then passed to a function called toDisplayCategorisedJob to display the job listing.

The generated HTML page will have a header with the $title, and a list of job listings based on the category or location selected.-->
<!--This code is defining variables and building a dynamic PHP page that displays job listings based on either a category or location. The variables include:

$title: a string that sets the title of the webpage
$catId: a variable that retrieves the category ID from the URL parameter catId
$c1, $c2, $c3, and $content: strings that contain PHP code, which is later included in the main PHP script to generate the page.
The code is using the selectFromTable function to retrieve job listings from a database based on the category ID or location provided. The retrieved data is then passed to a function called toDisplayCategorisedJob to display the job listing.

The generated HTML page will have a header with the $title, and a list of job listings based on the category or location selected.-->
