<?php
//session_start();
//requiring needed file
//require 'admin/connection.php';
//variable title to store a title of a page
$title ="Jo's Jobs - Apply";
//requiring a needed file
//require 'admin/adminHeader.php';
?>
<?php 
$content = '<!--main section of page-->
<main class="sidebar">
<!--left section of the page-->
<section class="left">
	<!-- requiring the left section file where needed-->
	<?php require\'admin/leftSectionBar.php\';?>
	</section>
	<!-- right section of the main content-->
	<section class="right">

<?php
$criteria = array();
//condition to check whether submit was clicked
if (isset($_POST[\'submit\'])) {
	////if there are no errors with the CV file upload
	if ($_FILES[\'cv\'][\'error\'] == 0) {
		//separate the file name and extension using explode function
		$parts = explode(\'.\', $_FILES[\'cv\'][\'name\']);
		//get the extension of the file
		$extension = end($parts);
		//create a unique file name
		$fileName = uniqid() . \'.\' . $extension;
		//move the uploaded file to the cvs folder
		move_uploaded_file($_FILES[\'cv\'][\'tmp_name\'], \'cvs/\' . $fileName);
		//create an array for the criteria for the applicant
		$criteria = [
			\'name\' => $_POST[\'name\'],
			\'email\' => $_POST[\'email\'],
			\'details\' => $_POST[\'details\'],
			\'jobId\' => $_POST[\'jobId\'],
			\'cv\' => $fileName
		];
		//preparing sql statement
		$stmt = $pdo->prepare(\'INSERT INTO applicants (name, email, details, jobId, cv)
					   VALUES (:name, :email, :details, :jobId, :cv)\');
		//executing the statement
		$stmt->execute($criteria);
		//echoing requslt
		echo \'Your application is complete. We will contact you after the closing date.\';
	}
	else {
		//echoin incase above condition failed
		echo \'There was an error uploading your CV\';
	}
}
else {
	//preparing
	$stmt = $pdo->prepare(\'SELECT * FROM job WHERE id = :id\');
	//executing
	$stmt->execute(array(\'id\' => $_GET[\'id\']));
	//fetchign
	$job = $stmt->fetch();
	?>
	<!-- form -->
	<?php $iid = $job[\'id\'];
	include\'apply-form-template.php\';
	?>
	<?php
	 }
	 ?>
	</section>
	</main>';
	?>

<?php
/*This code is defining the content of a page with the title "Jo's Jobs - Apply". It includes a form for job applicants to submit their information and upload their CV.

The code uses PHP to handle the form submission, checking for errors in the uploaded file and creating a unique file name for it. It then creates an array of the applicant's information and inserts it into the database using a prepared SQL statement.

The code also retrieves the job information from the database based on the ID passed in the URL, and includes a template for the application form with the job ID passed as a hidden input.

Overall, the code is well-structured and properly handles errors and database interactions. However, it would be helpful to see the contents of the included files (such as "leftSectionBar.php" and "apply-form-template.php") to fully understand the functionality of this page.
This code is defining the content of a page with the title "Jo's Jobs - Apply". It includes a form for job applicants to submit their information and upload their CV.

The code uses PHP to handle the form submission, checking for errors in the uploaded file and creating a unique file name for it. It then creates an array of the applicant's information and inserts it into the database using a prepared SQL statement.

The code also retrieves the job information from the database based on the ID passed in the URL, and includes a template for the application form with the job ID passed as a hidden input.

Overall, the code is well-structured and properly handles errors and database interactions. However, it would be helpful to see the contents of the included files (such as "leftSectionBar.php" and "apply-form-template.php") to fully understand the functionality of this <page class=""></page>*/
?>