<?php
$title = "jojo's -FAQs";
?>
<?php
$content ='
<main>
    <h2>FAQS coming soon</h2>
</main>';
?>
<!--The above code defines two PHP variables: $title and $content.

The $title variable is set to "jojo's -FAQs", which will be used as the title of the page.

The $content variable includes HTML markup wrapped inside PHP tags. It defines the main content section of the page, which in this case only contains an h2 heading "FAQS coming soon".

This code would be included in a larger PHP file that defines the structure and layout of the page, such as a template file. The $content variable would be inserted into the appropriate part of the template to display the main content of the page.-->
<!--The above code defines two PHP variables: $title and $content.

The $title variable is set to "jojo's -FAQs", which will be used as the title of the page.

The $content variable includes HTML markup wrapped inside PHP tags. It defines the main content section of the page, which in this case only contains an h2 heading "FAQS coming soon".

This code would be included in a larger PHP file that defines the structure and layout of the page, such as a template file. The $content variable would be inserted into the appropriate part of the template to display the main content of the page.-->
