<?php

//variable to hold page's title
$title = "Jo's Jobs - Contact";

?>

<?php
$content = '<?php
// Check if the form has been submitted
if(isset($_POST[\'submit\'])){
    // Collect the form data
    $email = $_POST[\'email\'];
    $enquiry = $_POST[\'enquiry\'];

    // Validate the form data
    if(empty($email) || empty($enquiry)){
        //echoing
        echo "Please complete all required fields.";
    } else {
        // Insert the enquiry into the database
        $sql = "INSERT INTO enquiries (email,enquiry) VALUES (\'$email\',\'$enquiry\')";
        //querying
        $pdo->query($sql);
        // echoing 
        echo "Thank you for your enquiry. We will get back to you as soon as possible.";
    }
}
?>

<!--main section of the page -->
<main>
<?php require\'enquiry-template.php\'?>
</main>';

?>
<!--
This code defines the $title and $content variables for the contact page of a website.

The $title variable is set to "Jo's Jobs - Contact".

The $content variable includes a PHP script that handles form submission for an enquiry form. It checks if the form has been submitted and if so, collects and validates the form data (email and enquiry message). If the form data is valid, it inserts the enquiry into a database table called "enquiries" and displays a thank you message.

The $content variable also includes a require statement to display the enquiry form using a separate template file called "enquiry-template.php".-->
<!--
This code defines the $title and $content variables for the contact page of a website.

The $title variable is set to "Jo's Jobs - Contact".

The $content variable includes a PHP script that handles form submission for an enquiry form. It checks if the form has been submitted and if so, collects and validates the form data (email and enquiry message). If the form data is valid, it inserts the enquiry into a database table called "enquiries" and displays a thank you message.

The $content variable also includes a require statement to display the enquiry form using a separate template file called "enquiry-template.php".-->
