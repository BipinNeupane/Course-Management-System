<?php

if(isset( $_GET['page'])){
	//requrmnt
	require $_GET['page'].'.php';
}else require'indexContent.php';
//variable to hold page's title
//$title = "Jo's Jobs - Home";
//requiring needed page
require'admin/adminHeader.php';
include'admin/commonFunction.php';
require'admin/connection.php';
include'admin/functions.php';
?>

		
		<?php 
		//displaying output 
		eval("?>".$content); ?>
			

	


	<?php
	//requirnig needed page
	require'admin/adminFooter.php';
	?>
<!--
	The first part of the code checks if the 'page' variable is set in the $_GET array. If it is set, it requires the corresponding PHP 
	file based on the value of the 'page' variable. If it is not set, it defaults to requiring the 'indexContent.php' file.
Next, the code requires some files related to the admin section of the website, including 'adminHeader.php', 'commonFunction.php', 
'connection.php', and 'functions.php'.
Then, the code uses the eval() function to output the contents of the $content variable, which presumably contains some HTML markup 
and/or PHP code. It's worth noting that using eval() can be risky if the $content variable is not properly sanitized, as it could 
potentially execute malicious code.
Finally, the code requires the 'adminFooter.php' file to finish up the page.
Overall, this code is a basic template for a website with an admin section. It's difficult to provide more specific feedback without 
seeing the contents of the included PHP files or knowing more about the website's overall functionality.
-->

<!--
	The first part of the code checks if the 'page' variable is set in the $_GET array. If it is set, it requires the corresponding PHP 
	file based on the value of the 'page' variable. If it is not set, it defaults to requiring the 'indexContent.php' file.
Next, the code requires some files related to the admin section of the website, including 'adminHeader.php', 'commonFunction.php', 
'connection.php', and 'functions.php'.
Then, the code uses the eval() function to output the contents of the $content variable, which presumably contains some HTML markup 
and/or PHP code. It's worth noting that using eval() can be risky if the $content variable is not properly sanitized, as it could 
potentially execute malicious code.
Finally, the code requires the 'adminFooter.php' file to finish up the page.
Overall, this code is a basic template for a website with an admin section. It's difficult to provide more specific feedback without 
seeing the contents of the included PHP files or knowing more about the website's overall functionality.
-->