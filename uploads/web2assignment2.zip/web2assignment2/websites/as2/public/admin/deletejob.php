<?php
session_start();
//error_reporting(0);
//requiring needed page
ob_start();
require 'connection.php';
ob_end_clean();
//condition to check if is logged in 
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
    // preparing sql statement
	$stmt = $pdo->prepare("UPDATE job SET status = 0 WHERE id = :id");
	//executing statement
	$stmt->execute(['id' => $_POST['id']]);

    //directing
	header('location: index.php?page=admin/jobs');
	exit;
}
?>


<!--This code updates the status of a job to 0 (which presumably means "inactive") in the database, based on the job's ID provided in the $_POST variable. It is used in an admin page to update job statuses.

The code starts by starting a session and requiring a connection.php file that presumably sets up the database connection using PDO. It then checks if the user is logged in and has the appropriate permissions to update job statuses.

If the conditions are met, the code prepares a SQL statement to update the status column of the job table to 0 where the id column matches the ID provided in the $_POST variable. The statement is then executed with the ID value bound to the parameter :id.

Finally, the user is redirected to the admin jobs page.-->
<!--This code updates the status of a job to 0 (which presumably means "inactive") in the database, based on the job's ID provided in the $_POST variable. It is used in an admin page to update job statuses.

The code starts by starting a session and requiring a connection.php file that presumably sets up the database connection using PDO. It then checks if the user is logged in and has the appropriate permissions to update job statuses.

If the conditions are met, the code prepares a SQL statement to update the status column of the job table to 0 where the id column matches the ID provided in the $_POST variable. The statement is then executed with the ID value bound to the parameter :id.

Finally, the user is redirected to the admin jobs page.-->