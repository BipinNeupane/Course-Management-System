          <?php 
			function toDisplayJob($requirement,$action,$value){
				echo '<table>';//
				echo '<thead>';//
				echo '<tr>';//
				echo '<th>Title</th>';//
				echo '<th style="width: 15%">Salary</th>';//
				echo '<th style="width: 15%">Category</th>';//
				echo '<th style="width: 5%">&nbsp;</th>';//
				echo '<th style="width: 15%">&nbsp;</th>';//
				echo '<th style="width: 5%">&nbsp;</th>';//
				echo '<th style="width: 5%">&nbsp;</th>';//
				echo '</tr>';//
				$requirement;//
	
				foreach ($requirement as $job) {
					global $pdo;//
					$applicants = $pdo->prepare('SELECT count(*) as count FROM applicants WHERE jobId = :jobId');//
	
					$applicants->execute(['jobId' => $job['id']]);//
	
					$applicantCount = $applicants->fetch();//
	
					echo '<tr>';//
					echo '<td>' . $job['title'] . '</td>';//
					echo '<td>' . $job['salary'] . '</td>';//
					//displaying the category of the jobs using where clause which selects the category name by category id
					$catNs = $pdo->query('SELECT * FROM category WHERE id ='.$job['categoryId'].'');
					//use of foreach loop to get a name of category one by one
					foreach($catNs as $catN ){
						//to display the category name
						echo '<td>' . $catN['name'] . '</td>';
					}
					echo '<td><a style="float: right" href="index.php?page=admin/addjob&id=' . $job['id'] . '">Edit</a></td>';//
					echo '<td><a style="float: right" href="index.php?page=admin/applicants&id=' . $job['id'] . '">View applicants (' . $applicantCount['count'] . ')</a></td>';
					echo '<td><form method="post" action="'.$action.'">
					<input type="hidden" name="id" value="' . $job['id'] . '" />
					<input type="submit" name="submit" value="'.$value.'" />
					</form></td>';//
					echo '</tr>';//
				}
	
				echo '</thead>';//
				echo '</table>';//
			}
			
//function to display jobs
function toDisplayCategorisedJob($j,$s,$d,$i){
    // use of for each loop to get data
		echo '<li>';
		echo '<div class="details">';
		echo '<h2>' . $j . '</h2>';
		echo '<h3>' . $s . '</h3>';
		echo '<p>' . nl2br($d) . '</p>';
		echo '<a class="more" href="index.php?page=apply&id=' . $i . '">Apply for this job</a>';
		echo '</div>';
		echo '</li>';
	}

?>
<!--The first function, toDisplayJob, is a PHP function that takes three arguments: $requirement, $action, and $value. It first outputs an HTML table header with seven columns: "Title," "Salary," "Category," and three empty columns for buttons.

Then, for each job in the $requirement array, it queries the database to get the number of applicants for that job, and outputs a table row with the job's title, salary, category name, and buttons for editing the job, viewing applicants, and performing the action specified in $action (with the job ID passed as a hidden form field and the button label set to $value).

The second function, toDisplayCategorisedJob, is a PHP function that takes four arguments: $j for job title, $s for job salary, $d for job description, and $i for job ID. It outputs an HTML list item with the job title, salary, description (with newlines converted to <br> tags), and a link to apply for the job with the job ID passed as a URL parameter.-->

<!--The first function, toDisplayJob, is a PHP function that takes three arguments: $requirement, $action, and $value. It first outputs an HTML table header with seven columns: "Title," "Salary," "Category," and three empty columns for buttons.

Then, for each job in the $requirement array, it queries the database to get the number of applicants for that job, and outputs a table row with the job's title, salary, category name, and buttons for editing the job, viewing applicants, and performing the action specified in $action (with the job ID passed as a hidden form field and the button label set to $value).

The second function, toDisplayCategorisedJob, is a PHP function that takes four arguments: $j for job title, $s for job salary, $d for job description, and $i for job ID. It outputs an HTML list item with the job title, salary, description (with newlines converted to <br> tags), and a link to apply for the job with the job ID passed as a URL parameter.-->