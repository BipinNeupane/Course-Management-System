<?php
	//echo '<ul>';
    //querying sql statement
    $categories = $pdo->query('SELECT * FROM category');
    //use of foreach loop to retrieve data
    foreach ($categories as $category) {
        //echoing
    echo '<li><a href="index.php?page=categoryJob&catId='.$category['id'].'">' . $category['name'] . '</a></li>';
    }
    //echo'	</ul>';
            ?>
<!--This code is querying a SQL statement to retrieve all categories from a table named "category". It then uses a foreach loop to iterate through each category and display a link to a page that lists all jobs in that category. The link includes the category's ID as a query parameter, which can be used to retrieve the appropriate jobs from the database. The code is currently commented out, as indicated by the double forward slashes at the beginning of each line-->
<!--This code is querying a SQL statement to retrieve all categories from a table named "category". It then uses a foreach loop to iterate through each category and display a link to a page that lists all jobs in that category. The link includes the category's ID as a query parameter, which can be used to retrieve the appropriate jobs from the database. The code is currently commented out, as indicated by the double forward slashes at the beginning of each line-->