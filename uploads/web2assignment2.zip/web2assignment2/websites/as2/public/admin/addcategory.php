<?php
session_start(); //start session
error_reporting(0);
$title ="Jo's Jobs - Add/Edit Category"; //setting title of the page

?>
	<?php
	$content = '<main class="sidebar">
	<!--using the code from leftSectionBar to reduce repetitiveness-->
	<?php
	require\'admin/leftSectionBar.php\'; // including left sidebar
	?>
	<!--code provided by university-->
	<!--right section of the main section-->
	<section class="right">
	
	<?php
	//checking whether the admin is logged in or not
		if (isset($_SESSION[\'loggedin\']) && $_SESSION[\'loggedin\'] == true) {
	//the code to run after admin is logged in
	//checking whether the submit button is clicked for add category
	if (isset($_POST[\'submit\']) && !isset($_POST[\'id\'])) {
		//code to be executed after submit button is clicked
		$stmt = $pdo->prepare(\'INSERT INTO category (name) VALUES (:name)\');// preparing sql statement
		//intiating a variable named criteria
		$criteria = [
		//name is the placeholder in above sql query
		//name will have the value that is posted in input of name and here we have gotten it by post method
		\'name\' => $_POST[\'name\']
		];
		//executing the above query
		$stmt->execute($criteria);
		//echoing the output
		echo \'Category added\';
		}
		//condition to check if submit is clicked
		else if (isset($_POST[\'submit\']) && isset($_POST[\'id\'])) {
		// preparing sql statement
		$stmt = $pdo->prepare(\'UPDATE category SET name = :name WHERE id = :id \');
		// variable to hold value
		$criteria = [
		\'name\' => $_POST[\'name\'],
		\'id\' => $_POST[\'id\']
		];
		//executing statement
		$stmt->execute($criteria);
		//echoing
		echo \'Category Saved\';
		}
		//condition to check if id is set
		else if (isset($_GET[\'id\'])) { //querying sql statement
		$currentCategory = $pdo->query(\'SELECT * FROM category WHERE id = \' . $_GET[\'id\'])->fetch();
		?>
					<!-- headline -->
					<h2>Edit Category</h2>
				<!-- use of form -->
				<form action="" method="POST">
					 <!-- input hidden type -->
					<input type="hidden" name="id" value="<?php echo $currentCategory[\'id\']; ?>" />
					<!-- labelling -->
					<label>Name</label>
					<!-- input text type -->
					<input type="text" name="name" value="<?php echo $currentCategory[\'name\']; ?>" />
					<!-- input submit type -->
					<input type="submit" name="submit" value="Save Category" />
				</form>
			<?php
		}
	else {
			?>
			<h2>Add Category</h2>
			<form action="" method="POST">
			<!-- labelling -->
			<label>Name</label>
			<!-- input with text type -->
			<input type="text" name="name" />
			<!-- input with submit type-->
			<input type="submit" name="submit" value="Add Category" />
			</form>
			<?php
			 }
			}
			else {
				 ?>
			<?php
			 //requiring needed page
			 require \'admin/login.php\';
			 }
			?>
			
			</section>
				</main>';
	
	?>
	<!--This is a PHP code that displays a page for adding or editing job categories in a job portal. The page has a left sidebar and a main section, which is further divided into a left and right section. The left section contains some navigation links, while the right section displays the form for adding/editing categories.

The code starts by setting the page title and then initiates a session. It also turns off the error reporting.

The variable $content holds the HTML code for the main section. It begins by including the left sidebar code. Then, it checks if the admin is logged in or not. If the admin is logged in, it checks if the submit button is clicked for adding or editing categories.

If the submit button is clicked for adding a new category, the code prepares a SQL statement to insert the category name into the database. It then executes the query and displays a success message. If the submit button is clicked for editing a category, the code prepares a SQL statement to update the category name in the database. It then executes the query and displays a success message.

If the ID parameter is set in the URL, it means the admin wants to edit an existing category. The code queries the database for the category with the given ID and displays a form to edit the category name. Finally, if the admin is not logged in, the code includes the login page.

Note: The code uses the PDO library to interact with the database, and it is assumed that the necessary database connection has already been established-->

<!--This is a PHP code that displays a page for adding or editing job categories in a job portal. The page has a left sidebar and a main section, which is further divided into a left and right section. The left section contains some navigation links, while the right section displays the form for adding/editing categories.

The code starts by setting the page title and then initiates a session. It also turns off the error reporting.

The variable $content holds the HTML code for the main section. It begins by including the left sidebar code. Then, it checks if the admin is logged in or not. If the admin is logged in, it checks if the submit button is clicked for adding or editing categories.

If the submit button is clicked for adding a new category, the code prepares a SQL statement to insert the category name into the database. It then executes the query and displays a success message. If the submit button is clicked for editing a category, the code prepares a SQL statement to update the category name in the database. It then executes the query and displays a success message.

If the ID parameter is set in the URL, it means the admin wants to edit an existing category. The code queries the database for the category with the given ID and displays a form to edit the category name. Finally, if the admin is not logged in, the code includes the login page.

Note: The code uses the PDO library to interact with the database, and it is assumed that the necessary database connection has already been established-->
