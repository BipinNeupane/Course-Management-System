<?php
session_start();
error_reporting(0);
$title = "Jo's Jobs - Admin Home";

?>
<?php
$content = '
<main class="sidebar">


	<?php
	if (isset($_POST["submit"])) {
		if (isset($_POST["user"])) {
			$stmt = selectFromTable("users", "*", array(
				"username" => $_POST["username"],
				"password" => $_POST["password"]
			));
			if (!empty($stmt)) {
				$_SESSION["loggedin"] = true;
				$_SESSION["check"] = 0;
				$_SESSION["userName"]=$_POST["username"];
			} else{
				echo "email or password didn\'t match";
			}
		} elseif (isset($_POST["client"])) {
			$stmt = selectFromTable("clients", "*", array(
				"username" => $_POST["username"],
				"password" => $_POST["password"]
			));
			if (!empty($stmt)) {
				$_SESSION["loggedin"] = true;
				$_SESSION["check"] = 1;
				$_SESSION["client"] = $_POST["username"];
			}else{
				echo "email or password didn\'t match";
			}
		} else {
			echo "Please choose an account type";
		}
	}


	if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] == true) {
	?>
	<!--requiring the code from file leftSectionBar to reduce the repetativeness of the code-->
	<?php
	require "admin/leftSectionBar.php";
	?>

	<section class="right">
	<h2>You are now logged in</h2>
	</section>
	<?php
	}
	else {
	require"admin/login.php";
	}
	?>
	</main>';
?>


<!--This code appears to be a PHP script for displaying the main content of a web page.

The first section sets some variables, including the page title and starts a session.

The second section checks if the login form has been submitted and if the username and password match those in the database. If they match, the user is logged in and the left section bar is required from another file, and the logged-in content is displayed. If the user is not logged in, the login form is displayed.

It's worth noting that the code has some potential security issues, including the use of the error_reporting() function to suppress error messages, which could hide important security warnings. Additionally, the code does not appear to be sanitizing user input before it is used in SQL queries, which could allow for SQL injection attacks.-->

<!--This code appears to be a PHP script for displaying the main content of a web page.

The first section sets some variables, including the page title and starts a session.

The second section checks if the login form has been submitted and if the username and password match those in the database. If they match, the user is logged in and the left section bar is required from another file, and the logged-in content is displayed. If the user is not logged in, the login form is displayed.

It's worth noting that the code has some potential security issues, including the use of the error_reporting() function to suppress error messages, which could hide important security warnings. Additionally, the code does not appear to be sanitizing user input before it is used in SQL queries, which could allow for SQL injection attacks.-->