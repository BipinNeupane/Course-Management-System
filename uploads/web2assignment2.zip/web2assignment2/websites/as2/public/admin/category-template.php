<?php
//use of table
echo '<table>';
//echoing
echo '<thead>';
//echoing
echo '<tr>';
//echoing
echo '<th>Name</th>';
//echoing
echo '<th style="width: 5%">&nbsp;</th>';
//echoing
echo '<th style="width: 5%">&nbsp;</th>';
//echoing
echo '</tr>';
// querying a statement
$categories = $pdo->query('SELECT * FROM category');
// use of foreach loop to retrieve data
foreach ($categories as $category) {
    echo '<tr>';
    //echoing
    echo '<td>' . $category['name'] . '</td>';
    echo '<td><a style="float: right" href="index.php?page=admin/addcategory&id=' . $category['id'] . '">Edit</a></td>';
    echo '<td><form method="post" action="index.php?page=admin/deletecategory">
    <input type="hidden" name="id" value="' . $category['id'] . '" />
    <input type="submit" name="submit" value="Delete" />
    </form></td>';
    echo '</tr>';
}

echo '</thead>';
echo '</table>';
?>
<!--This PHP code creates an HTML table to display a list of categories retrieved from a database using PDO.

The echo '<table>' starts an HTML table, and echo '<thead>' starts the table header. The next echo '<tr>' creates a table row for the header with three columns for the name, edit button, and delete button. The echo '</tr>' ends the header row.

Next, the code queries the database using $categories = $pdo->query('SELECT * FROM category'); and uses a foreach loop to display the retrieved data in each row of the table. The name of each category is displayed in the first column, while the edit and delete buttons are placed in the second and third columns, respectively.

Finally, the code ends the table header and table using echo '</thead>' and echo '</table>'-->
<!--This PHP code creates an HTML table to display a list of categories retrieved from a database using PDO.

The echo '<table>' starts an HTML table, and echo '<thead>' starts the table header. The next echo '<tr>' creates a table row for the header with three columns for the name, edit button, and delete button. The echo '</tr>' ends the header row.

Next, the code queries the database using $categories = $pdo->query('SELECT * FROM category'); and uses a foreach loop to display the retrieved data in each row of the table. The name of each category is displayed in the first column, while the edit and delete buttons are placed in the second and third columns, respectively.

Finally, the code ends the table header and table using echo '</thead>' and echo '</table>'-->