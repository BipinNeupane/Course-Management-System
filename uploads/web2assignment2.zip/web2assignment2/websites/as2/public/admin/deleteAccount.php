<?php
session_start();
//error_reporting(0);
ob_start();
//requiring needed page
require 'connection.php';
ob_end_clean();
//condition to check if is logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
    // preparing sql statement
	$stmt = $pdo->prepare("DELETE  FROM users WHERE id = :id");
	//executing statement
	$stmt->execute(['id' => $_POST['id']]);

    //directing
	header('location: index.php?page=admin/userAccount');
	exit;
}


//This code appears to be a script that handles deleting a user account. It checks if the user is logged in and if the POST request for deleting a user account has been made. If the conditions are met, it prepares a SQL statement to delete the user account with the specified ID and executes it. Finally, it redirects the user to the user account page in the admin section-->
//This code appears to be a script that handles deleting a user account. It checks if the user is logged in and if the POST request for deleting a user account has been made. If the conditions are met, it prepares a SQL statement to delete the user account with the specified ID and executes it. Finally, it redirects the user to the user account page in the admin section-->