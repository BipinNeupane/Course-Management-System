<?php

$pdo = new PDO('mysql:dbname=job;host=db', 'root', 'root',[PDO::ATTR_ERRMODE=> PDO::ERRMODE_EXCEPTION]);
$pdo->query('ALTER TABLE users MODIFY COLUMN id INT NOT NULL AUTO_INCREMENT');
$pdo->query('ALTER TABLE clients MODIFY COLUMN id INT NOT NULL AUTO_INCREMENT');
//$pdo->query('ALTER TABLE job ADD clientName VARCHAR(255)');
//$pdo->query('ALTER TABLE job ADD FOREIGN KEY (clientName) REFERENCES clients(clientName)');
//$pdo->query('INSERT INTO users(username,password)VALUES("admin","ronaldo7")');
//$sql = 'CREATE TABLE enquiries (
    //id INT AUTO_INCREMENT PRIMARY KEY,
    //email VARCHAR(255) NOT NULL,
    //enquiry TEXT NOT NULL,
    //complete_status BOOLEAN NOT NULL DEFAULT 0,
    //reply TEXT ,
    //username VARCHAR(255)
    //)';
//$pdo->query($sql);

?>
<!--The code  contains commented out lines that are used to modify the structure of the database tables, insert data into tables, and create a new table. These lines can be uncommented and executed to make the necessary changes to the database.

Note that modifying the structure of the database tables or inserting data can have significant consequences on the application, so it is important to make sure that the changes are necessary and tested thoroughly before making them in a production environment.-->
<!--The code  contains commented out lines that are used to modify the structure of the database tables, insert data into tables, and create a new table. These lines can be uncommented and executed to make the necessary changes to the database.

Note that modifying the structure of the database tables or inserting data can have significant consequences on the application, so it is important to make sure that the changes are necessary and tested thoroughly before making them in a production environment.-->