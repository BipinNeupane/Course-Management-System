<?php
session_start();
error_reporting(0);
ob_start();
require 'connection.php';
ob_end_clean();
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {

	$stmt = $pdo->prepare("UPDATE job SET status = 1 WHERE id = :id");
	$stmt->execute(['id' => $_POST['id']]);


	header('location:index.php?page=admin/archive');
	exit;
}
?>
<!--This is a PHP script that updates a job record in the database by setting its status to 1 (which means it's archived). It takes the ID of the job from a POST request and uses it to prepare and execute an SQL statement that updates the corresponding record in the database. Finally, it redirects the user to the archive page.

However, this code is missing some error handling. For example, it doesn't check whether the ID is valid or whether the SQL statement was executed successfully. It would be good to add some error handling code to ensure the script runs correctly and doesn't break if there are any issues.-->
<!--This is a PHP script that updates a job record in the database by setting its status to 1 (which means it's archived). It takes the ID of the job from a POST request and uses it to prepare and execute an SQL statement that updates the corresponding record in the database. Finally, it redirects the user to the archive page.

However, this code is missing some error handling. For example, it doesn't check whether the ID is valid or whether the SQL statement was executed successfully. It would be good to add some error handling code to ensure the script runs correctly and doesn't break if there are any issues.-->