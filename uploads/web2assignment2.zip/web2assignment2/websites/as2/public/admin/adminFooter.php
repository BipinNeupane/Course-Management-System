<!--this is the footer layout to reduce the coding it for multiple times in different pages 
here we are making seperate file for footer layout and it can be accessed in other pages by using command require-->
<footer>
    <!--here i am echoing the current date for the copyright section so it update along with the year-->
		&copy; Jo's Jobs <?php echo date("Y"); ?>
	</footer>
</body>
</html>
<!--This is a good practice to use a separate file for footer layout to avoid duplicating code in multiple pages. The use of PHP's date() function to dynamically display the current year is also a good practice for maintaining up-to-date information. Overall, this is a well-structured and efficient way to implement a footer section in a web page-->