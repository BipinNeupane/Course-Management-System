<h2>Log in</h2>

			<form action="index.php?page=admin/index" method="post">
				<!--labelling using label tag dispalying-->
			    <label>Username</label>
				<!--input for user to enter somthinf-->
				<input type="text" name="username" />
				<!--labelling using label tag dispalying-->
				<label>Password</label>
				<!--input for user to enter somthinf-->
				<input type="password" name="password" />
				<!--labelling using label tag dispalying-->
                <label for="user">user</label>
				<!--input for user to enter somthinf-->
                <input type="radio" name="user">
				<!--labelling using label tag dispalying-->
				<label for="client">client</label>
				<!--input for user to enter somthinf-->
				<input type="radio" name="client" >
				<!--input for user to enter somthinf-->
				<input type="submit" name="submit" value="Log In" />
			</form>
<!--The above code appears to be a mix of HTML and PHP, where the PHP code is used to dynamically generate content for the web page. -->
<!--The above code appears to be a mix of HTML and PHP, where the PHP code is used to dynamically generate content for the web page. -->