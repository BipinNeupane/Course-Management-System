<?php
session_start();
//connection to database is used here 
require'connection.php';
//setting variable named title
$title ="Jo's Jobs - Edit Accounts";
//using the layout header
$id = $_GET['id'];
$users = $pdo->query('SELECT * FROM users WHERE id ='. $id.'');
foreach($users as $user){
    $userN = $user['username'];
    $pass = $user['password'];
}
require'adminHeader.php';
?>
	<main class="sidebar">
<!--using the code from leftSectionBar to reduce repetitiveness-->
	<?php
	require'leftSectionBar.php';
	?>
<!--code provided by university-->
<!--right section of the main section-->
	<section class="right">

	<?php
	//checking whether the admin is logged in or not
		if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {

//the code to run after admin is logged in
//checking whether the submit button is clicked
$row = 0;
	if (isset($_POST['submit'])) {
       // $username = $pdo->quote($_POST['name']);
       // $stmt = $pdo->query('SELECT * FROM users WHERE username = '.$username.'');
       // $row = $stmt->rowCount();
       // if($row==0){
//code to be executed after submit button is clicked
		$stmt = $pdo->prepare('UPDATE users SET username =:name, password = :password WHERE id ='.$id.'');
//intiating a variable named criteria
		$criteria = [
			//name is the placeholder in above sql query 
			//name will have the value that is posted in input of name and here we have gotten it by post method
			'name' => $_POST['name'],
            'password'=>$_POST['password']
		];
//executing the above query 
		$stmt->execute($criteria);
		//echoing the output
		echo 'Account edited';
	}
	else {
		?>
<!--below code are for if if condition is false-->

			<h2>Edit Account</h2>
<!--forming a form with method post-->
			<form action="" method="POST">
				<!--labelling-->
				<label>Username</label>
				<!-- input text type -->
				<input type="text" name="name" value= "<?php echo $userN;?>"required/>
				<!--labelling-->
                <label>Password</label>
				<!-- input text type -->
                <input type="text" name="password" value=" <?php echo $pass;?>" required/>

				<input type="submit" name="submit" value="Edit Account" />

			</form>


		<?php
		}



	}
	else {
			?>
		<?php
		require 'login.php';
		}
	?>


</section>
	</main>
<!--requiring footer layout-->
	<?php
	require 'adminFooter.php';
	?>
<!--This code seems to be a PHP script that allows an admin user to edit an existing user account. It starts by starting a session and requiring a connection to the database. Then, it sets the $title variable and requires the admin header layout.

The code retrieves the user account information from the database and displays it in a form to allow the admin to edit the user's username and password. If the form is submitted, the code updates the user account information in the database.

Overall, the code seems to be functioning correctly and does not have any syntax errors. However, it is important to note that this code does not include any validation or sanitization of user input, which could lead to security vulnerabilities. It is important to include input validation and sanitization in any web application to prevent attacks such as SQL injection and cross-site scripting.-->
<!--This code seems to be a PHP script that allows an admin user to edit an existing user account. It starts by starting a session and requiring a connection to the database. Then, it sets the $title variable and requires the admin header layout.

The code retrieves the user account information from the database and displays it in a form to allow the admin to edit the user's username and password. If the form is submitted, the code updates the user account information in the database.

Overall, the code seems to be functioning correctly and does not have any syntax errors. However, it is important to note that this code does not include any validation or sanitization of user input, which could lead to security vulnerabilities. It is important to include input validation and sanitization in any web application to prevent attacks such as SQL injection and cross-site scripting.-->