<?php
session_start();
//to remove warning
error_reporting(0);
$title = "jo jo's -logout";

?>
<?php
$content ='
<main class="sidebar">
<?php
require\'admin/leftSectionBar.php\';
?>
<section class="right">
    <form action="#" method="POST">
    <button name=\'logout\'>logout</button>
    <?php
    if(isset($_POST[\'logout\'])){
        unset($_SESSION[\'loggedin\']);
        echo\'you are logged out\';
        }
    ?>
</form>
</section>
</main>';
?>
<!--This code creates a page for logging out a user from the website. It starts a session, sets the title of the page, and suppresses any error messages.

The $content variable contains HTML and PHP code for displaying the page. It includes a left sidebar with links to other sections of the website and a right section with a form for logging out.

When the user clicks the "logout" button, the form is submitted and a PHP script checks if the button was clicked by checking the $_POST array. If the button was clicked, the script unsets the $_SESSION['loggedin'] variable and displays a message saying "you are logged out".-->
<!--This code creates a page for logging out a user from the website. It starts a session, sets the title of the page, and suppresses any error messages.

The $content variable contains HTML and PHP code for displaying the page. It includes a left sidebar with links to other sections of the website and a right section with a form for logging out.

When the user clicks the "logout" button, the form is submitted and a PHP script checks if the button was clicked by checking the $_POST array. If the button was clicked, the script unsets the $_SESSION['loggedin'] variable and displays a message saying "you are logged out".-->