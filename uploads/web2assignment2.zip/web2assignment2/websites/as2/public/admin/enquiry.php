<?php
session_start();
error_reporting(0);
$title = "jo jo's enquiry";

?>
<?php
$content = '<main class="sidebar">
<!--section of left bar is included here to reduce repetitiveness of code-->
	<?php
	require\'admin/leftSectionBar.php\';
	?>
<!--right section-->
	<section class="right">
    <?php

if (isset($_SESSION[\'loggedin\']) && $_SESSION[\'loggedin\'] == true) {
?>
    <div>
        <a href="index.php?page=admin/enquiry&status=0">Uncompleted</a>
        <a href="index.php?page=admin/enquiry&status=1">Completed</a>
    </div>
<?php
    if (isset($_GET[\'status\'])) {
            if($_GET[\'status\'] == 1){
                ?>
              <table>
        <thead>
            <tr>
                <th>Email</th>
                <th>Enquiry</th>
                <th>completed by</th>
            </tr>
        </thead>
        <tbody>
            <?php $enquiries = $pdo->query("SELECT  * FROM enquiries WHERE complete_status = 1");
            foreach($enquiries as $enquiry) { ?>
                <tr>
                    <td><?php echo $enquiry[\'email\']; ?></td>
                    <td><?php echo $enquiry[\'enquiry\']; ?></td>
                    <td><?php echo $enquiry[\'username\'];?></td>
                </tr>
            <?php 
        } ?>
        </tbody>
    </table>
           <?php }else{?>
            <table>
            <thead>
                <tr>
                    <th>Email</th>
                    <th>Enquiry</th>
                    <th>Answer</th>
                </tr>
            </thead>
            <tbody>
                <?php $enquiries = $pdo->query("SELECT  id,email, enquiry FROM enquiries WHERE complete_status = 0");
                foreach($enquiries as $enquiry) { ?>
                    <tr>
                        <td><?php echo $enquiry[\'email\']; ?></td>
                        <td><?php echo $enquiry[\'enquiry\']; ?></td>
                        <td>
                            <form action="" method="post">
                                <input type="hidden" name="id" value="<?php echo $enquiry[\'id\']; ?>">
                                <textarea name="answer"></textarea>
                                <input type="submit" name="submit" value="Answer">
                            </form>
                        </td>
                    </tr>
                <?php 
            } ?>
            </tbody>
            </table>
       <?php }
        ?>
    <?php
    }
    ?>
    <?php
}else{
    require\'admin/login.php\';
}?>
</section>
</main>
<?php 
if(isset($_POST[\'submit\'])){
    $id = $_POST[\'id\'];
    $answer = $_POST[\'answer\'];
    // Prepare the update statement
    $stmt = $pdo->prepare("UPDATE enquiries SET reply=:answer, complete_status = 1, username=:user WHERE id=:id");
    $stmt->bindParam(\':answer\', $answer);
    $stmt->bindParam(\':user\', $_SESSION[\'userName\']);
    $stmt->bindParam(\':id\', $id);
    $stmt->execute();
    echo "Enquiry has been updated successfully";
}   
?>';
?>

<!--This is a PHP code that generates a page for managing enquiries on a website's admin panel.

The code starts with starting a session and suppressing any error reporting. It sets the title of the page to "jo jo's enquiry".

The content of the page includes a left sidebar and a right section. The left sidebar is included using the require statement, which includes another PHP file that contains the HTML code for the sidebar.

The right section includes a condition that checks if the user is logged in and if their loggedin session variable is set to true. If the user is logged in, the section displays two links for filtering enquiries by their status: completed or uncompleted. Depending on the status selected, the section displays a table of enquiries.

If the status selected is completed, the section displays a table of completed enquiries that includes the email, enquiry, and username of the user who completed the enquiry.

If the status selected is uncompleted, the section displays a table of uncompleted enquiries that includes the email, enquiry, and a form for answering the enquiry. The form includes a hidden field for the enquiry ID, a textarea for the answer, and a submit button.

The content also includes a PHP script that updates the database with the answer to the enquiry and changes the status to completed when the user submits the form.

Overall, this code provides a basic functionality for managing enquiries on a website's admin panel. However, it is important to note that the code does not include any security measures, such as input validation and protection against SQL injection attacks, and should not be used in a production environment without further modifications-->
<!--This is a PHP code that generates a page for managing enquiries on a website's admin panel.

The code starts with starting a session and suppressing any error reporting. It sets the title of the page to "jo jo's enquiry".

The content of the page includes a left sidebar and a right section. The left sidebar is included using the require statement, which includes another PHP file that contains the HTML code for the sidebar.

The right section includes a condition that checks if the user is logged in and if their loggedin session variable is set to true. If the user is logged in, the section displays two links for filtering enquiries by their status: completed or uncompleted. Depending on the status selected, the section displays a table of enquiries.

If the status selected is completed, the section displays a table of completed enquiries that includes the email, enquiry, and username of the user who completed the enquiry.

If the status selected is uncompleted, the section displays a table of uncompleted enquiries that includes the email, enquiry, and a form for answering the enquiry. The form includes a hidden field for the enquiry ID, a textarea for the answer, and a submit button.

The content also includes a PHP script that updates the database with the answer to the enquiry and changes the status to completed when the user submits the form.

Overall, this code provides a basic functionality for managing enquiries on a website's admin panel. However, it is important to note that the code does not include any security measures, such as input validation and protection against SQL injection attacks, and should not be used in a production environment without further modifications-->