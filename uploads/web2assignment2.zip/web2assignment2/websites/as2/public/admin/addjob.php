<?php
session_start();
error_reporting(0);
$title = "Jo's Jobs - Add/Edit Job";

?>
<?php
$content = '<main class="sidebar">
<?php
//requiring needed page
require\'admin/leftSectionBar.php\';
?>
<!-- right section of the main -->
<section class="right">
<?php
// Check if the script is being used for adding or editing a job
if (isset($_SESSION[\'loggedin\']) && $_SESSION[\'loggedin\'] == true) {
if (isset($_POST[\'submit\'])) {
    if (isset($_GET[\'id\'])) {
        // Updating a job
        $stmt = $pdo->prepare(\'UPDATE job SET title = :title, description = :description, salary = :salary, location = :location, categoryId = :categoryId, closingDate = :closingDate WHERE id = :id\');
        $criteria = [
            \'title\' => $_POST[\'title\'],
            \'description\' => $_POST[\'description\'],
            \'salary\' => $_POST[\'salary\'],
            \'location\' => $_POST[\'location\'],
            \'categoryId\' => $_POST[\'categoryId\'],
            \'closingDate\' => $_POST[\'closingDate\'],
            \'id\' => $_GET[\'id\']
        ];
        $stmt->execute($criteria);
        echo \'Job saved\';
    } else {
        // Adding a new job
        if($_SESSION[\'check\'] == 1){
			$stmt = $pdo->prepare(\'INSERT INTO job (title, description, salary, location, closingDate, categoryId, status, clientName) VALUES (:title, :description, :salary, :location, :closingDate, :categoryId, 1, :clientName)\');
			$criteria = [
				\'title\' => $_POST[\'title\'],
				\'description\' => $_POST[\'description\'],
				\'salary\' => $_POST[\'salary\'],
				\'location\' => $_POST[\'location\'],
				\'categoryId\' => $_POST[\'categoryId\'],
				\'closingDate\' => $_POST[\'closingDate\'],
                \'clientName\' => $_SESSION[\'client\']
			];
			$stmt->execute($criteria);
			echo \'Job Added\';
		}else {
            $stmt = $pdo->prepare(\'INSERT INTO job (title, description, salary, location, closingDate, categoryId, status) VALUES (:title, :description, :salary, :location, :closingDate, :categoryId, 1)\');
			$criteria = [
				\'title\' => $_POST[\'title\'],
				\'description\' => $_POST[\'description\'],
				\'salary\' => $_POST[\'salary\'],
				\'location\' => $_POST[\'location\'],
				\'categoryId\' => $_POST[\'categoryId\'],
				\'closingDate\' => $_POST[\'closingDate\'],
			];
			$stmt->execute($criteria);
			echo \'Job Added\';
        }
    }
} else {
        if (isset($_GET[\'id\'])) {
            
            // Retrieving a job for editing
            $stmt = $pdo->prepare(\'SELECT * FROM job WHERE id = :id\');
            $stmt->execute(array(\':id\'=>$_GET[\'id\']));
            $job = $stmt->fetch();
        }

        // Displaying the add/edit form

        ?>
        <h2>Add/Edit Job</h2>
        <form action="" method="POST">

            <input type="hidden" name="iid" value="<?php echo isset($job) ? $job[\'id\'] : ""; ?>" required/>
            <label>Title</label>
            <input type="text" name="title" value="<?php echo isset($job) ? $job[\'title\'] : ""; ?>" required/>
            <label>Description</label>
            <textarea name="description"><?php echo isset($job) ? $job[\'description\'] : ""; ?></textarea>
            <label>Salary</label>
            <input type="text" name="salary" value="<?php echo isset($job) ? $job[\'salary\'] : ""; ?>" required />
            <label>Location</label>
            <input type="text" name="location" value="<?php echo isset($job) ? $job[\'location\'] : ""; ?>" required/>
            <label>Closing Date</label>
            <input type="date" name="closingDate" value="<?php echo isset($job) ? $job[\'closingDate\'] : ""; ?>" required/>
            <label>Category</label>
            <select name="categoryId">
                <?php
                $stmt = $pdo->prepare(\'SELECT * FROM category\');
                $stmt->execute();
                foreach ($stmt as $row) {
                    if (isset($job) && $job[\'categoryId\'] == $row[\'id\']) {
                        echo \'<option value="\' . $row[\'id\'] . \'" selected>\' . $row[\'name\'] . \'</option>\';
                    } else {
                        echo \'<option value="\' . $row[\'id\'] . \'">\' . $row[\'name\'] . \'</option>\';
                    }
                }
                ?>
            </select>
            <input type="submit" name="submit" value="Save" />
        </form>
    <?php
    } 
}else {
    require\'admin/login.php\';
}?>
 </section>
            </main>';
            ?>

<!--This is a PHP script for adding or editing job listings on a website. It starts by starting a session and disabling error reporting, then setting the page title to "Jo's Jobs - Add/Edit Job". The main content of the page is defined as a string in the PHP variable $content.

The $content variable contains HTML code for the layout of the page, which includes a sidebar and a main section with a form for adding or editing job listings. The main section also includes PHP code for handling the form submission, database queries, and displaying error/success messages.

The PHP code checks if the user is logged in, and if so, checks if the form has been submitted. If the form has been submitted, it checks if the job ID is set, and updates the job if it is. If the job ID is not set, it adds a new job to the database.

If the form has not been submitted, the PHP code checks if a job ID is set and retrieves the job from the database if it is. It then displays the add/edit form with the job information populated if it exists.

If the user is not logged in, it requires a login page to be displayed.

Note: It is unclear if this code will work as intended without additional code for setting up the database connection and handling user authentication-->

<!--This is a PHP script for adding or editing job listings on a website. It starts by starting a session and disabling error reporting, then setting the page title to "Jo's Jobs - Add/Edit Job". The main content of the page is defined as a string in the PHP variable $content.

The $content variable contains HTML code for the layout of the page, which includes a sidebar and a main section with a form for adding or editing job listings. The main section also includes PHP code for handling the form submission, database queries, and displaying error/success messages.

The PHP code checks if the user is logged in, and if so, checks if the form has been submitted. If the form has been submitted, it checks if the job ID is set, and updates the job if it is. If the job ID is not set, it adds a new job to the database.

If the form has not been submitted, the PHP code checks if a job ID is set and retrieves the job from the database if it is. It then displays the add/edit form with the job information populated if it exists.

If the user is not logged in, it requires a login page to be displayed.

Note: It is unclear if this code will work as intended without additional code for setting up the database connection and handling user authentication-->
