<?php
session_start();
error_reporting(0);
//setting variable named title
$title ="Jo's Jobs - Add/Edit Accounts";
?>
<?php
$content = '
<main class="sidebar">
<!--using the code from leftSectionBar to reduce repetitiveness-->
<?php
$id = isset($_GET[\'id\']) ? $_GET[\'id\'] : null;
if($id != null){
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
$stmt->execute(array(\':id\' => $id));
$users = $stmt->fetchAll();
    foreach($users as $user){
        $userN = $user[\'username\'];
        $pass = $user[\'password\'];
    }
}
require\'admin/leftSectionBar.php\';
?>
<!--code provided by university-->
<!--right section of the main section-->
<section class="right">
    <?php
//checking whether the admin is logged in or not
if (isset($_SESSION[\'loggedin\']) && $_SESSION[\'loggedin\'] == true) {
        //the code to run after admin is logged in
        //checking whether the submit button is clicked
        $row = 0;
        if (isset($_POST[\'submit\'])) {
            if($id == null){
                $username = $pdo->quote($_POST[\'name\']);
                if(isset($_POST[\'user\'])){
                    $stmt = $pdo->query(\'SELECT * FROM users WHERE username = \'.$username."");
                    $row = $stmt->rowCount();
                    if($row==0){
                    //code to be executed after submit button is clicked
                    $stmt = $pdo->prepare(\'INSERT INTO users (username,password) VALUES (:name,:password)\');
					//intiating a variable named criteria
					$criteria = [
					//name is the placeholder in above sql query
					//name will have the value that is posted in input of name and here we have gotten it by post method
					\'name\' => $_POST[\'name\'],
					\'password\'=>$_POST[\'password\']
					];
					//executing the above query
					$stmt->execute($criteria);
					//echoing the output
					echo \'Account created\';
					}else{
					//echoing
					echo "username is taken";
					}
					}elseif(isset($_POST[\'client\'])){
					//querying sql statement
					$stmt = $pdo->query(\'SELECT * FROM clients WHERE username = \'.$username."");
					$row = $stmt->rowCount();
					if($row==0){
					//code to be executed after submit button is clicked
					$stmt = $pdo->prepare(\'INSERT INTO clients (username,password) VALUES (:name,:password)\');
					//intiating a variable named criteria
					$criteria = [
					//name is the placeholder in above sql query
					//name will have the value that is posted in input of name and here we have gotten it by post method
					\'name\' => $_POST[\'name\'],
                    \'password\'=>$_POST[\'password\']
					];
					//executing the above query
					$stmt->execute($criteria);
					//echoing the output
					echo \'Account created\';
					}else{
					//echoing
					echo "username is taken";
					}
					}else{
					echo "choose account\'s type";
					}
					} //condition to check if id is passed
					elseif(isset($_GET[\'id\'])){
					//setting variable id
					$id = $_GET[\'id\'];
					$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
                    $stmt->execute(array(\':id\' => $id));
                    $users = $stmt->fetchAll();
					foreach($users as $user){
					$userN = $user[\'username\'];
					$pass = $user[\'password\'];
					}
					
					//code to be executed after submit button is clicked
					$id = intVal($_GET[\'id\']);
					$stmt = $pdo->prepare("UPDATE users SET username =:name, password = :password WHERE id =:id");
					//intiating a variable named criteria
					$criteria = [
						//name is the placeholder in above sql query
                        //name will have the value that is posted in input of name and here we have gotten it by post method
                        \'name\' => $_POST[\'name\'],
                        \'password\'=>$_POST[\'password\'],
						\'id\'=>$id
                       ];
                        //executing the above query
						$stmt->execute($criteria);
                       //echoing the output
                       echo\'Account edited\';
					}
		}
					//else for if condition is false
					elseif($id == null ){
					?>
					<!--below code are for if if condition is false-->
					<h2>Add Account</h2>
					<!--forming a form with method post-->
					<form action="" method="POST">
					<!-- labelling -->
					<label>Username</label>
					<!-- input with text type-->
					<input type="text" name="name" required/>
					<!-- labelling -->
					<label>Password</label>
					<!-- input with text type-->
					<input type="text" name="password" required/>
					<!-- labelling -->
					<label for="user">user</label>
					<!-- input with type radio-->
					<input type="radio" name="user">
					<!-- labelling -->
					<label for="client">client</label>
					<!-- input with type radio-->
					<input type="radio" name="client">
					<!-- input with type submit-->
					<input type="submit" name="submit" value="Add Account" />
					</form>
					<?php
					}
                       elseif(isset($_GET[\'id\'])){
                     ?>
                     <!--below code are for if if condition is false-->
                     <h2>Edit Account</h2>
                    <!--forming a form with method post-->
                     <form action="" method="POST">
                    <!--labelling-->
                    <label>Username</label>
                    <!-- input text type -->
                    <input type="text" name="name" value= "<?php echo $userN;?>"required/>
                    <!--labelling-->
                    <label>Password</label>
                    <!-- input text type -->
                    <input type="text" name="password" value=" <?php echo $pass;?>" required/>
                    <!-- input submit type -->
                    <input type="submit" name="submit" value="Edit Account" />
                 </form>
 <?php
             }
             }
         else {
             ?>
<?php
             require \'admin/login.php\';
             }
         ?>
</section>
</main>
';
?>

<!--This is a PHP code that is responsible for creating and editing user accounts.

First, it starts a session and disables error reporting. Then, it defines a variable named "title" with the value "Jo's Jobs - Add/Edit Accounts".

It creates a HTML content by forming a form that asks the user to enter the username and password. It then checks whether the admin is logged in or not. If logged in, it checks whether the submit button is clicked or not. If the submit button is clicked, the code then checks whether the username and password values are set in the $_POST array.

If the ID is not null, the code retrieves the user's details using PDO and SQL queries. If the ID is null, it means the user is adding a new user account. In this case, the code queries the database to see if the username is already taken. If it is not, the code inserts a new row with the username and password values.

If the ID is not null, it means the user is editing an existing account. In this case, the code retrieves the user's details from the database and updates the values with new ones.

Finally, the code displays an appropriate message on the screen to inform the user about the success or failure of the operation.-->
<!--This is a PHP code that is responsible for creating and editing user accounts.

First, it starts a session and disables error reporting. Then, it defines a variable named "title" with the value "Jo's Jobs - Add/Edit Accounts".

It creates a HTML content by forming a form that asks the user to enter the username and password. It then checks whether the admin is logged in or not. If logged in, it checks whether the submit button is clicked or not. If the submit button is clicked, the code then checks whether the username and password values are set in the $_POST array.

If the ID is not null, the code retrieves the user's details using PDO and SQL queries. If the ID is null, it means the user is adding a new user account. In this case, the code queries the database to see if the username is already taken. If it is not, the code inserts a new row with the username and password values.

If the ID is not null, it means the user is editing an existing account. In this case, the code retrieves the user's details from the database and updates the values with new ones.

Finally, the code displays an appropriate message on the screen to inform the user about the success or failure of the operation.-->