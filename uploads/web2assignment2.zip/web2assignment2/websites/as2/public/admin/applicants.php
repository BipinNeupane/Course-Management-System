<?php
// start a new session
session_start();
error_reporting(0);
//set the title variable to "Jo's Jobs - Apply"
$title = "Jo's Jobs - Applicants";

?>

<?php
//store the corrected code in variable $content
$content ='<main class="sidebar">

<?php
//require the leftSectionBar.php file
require\'admin/leftSectionBar.php\';
?>

<section class="right">

<?php

	//if the user is logged in
	if (isset($_SESSION[\'loggedin\']) && $_SESSION[\'loggedin\'] == true) {

		//prepare and execute a query to select the job from the database
		$stmt = $pdo->prepare(\'SELECT * FROM job WHERE id = :id\');
		$stmt->execute([\'id\' => $_GET[\'id\']]);
		$job = $stmt->fetch();
	?>


		<h2>Applicants for <?=$job[\'title\'];?></h2>

		<?php
		//create a table to display the applicants
		echo \'<table>\';
		echo \'<thead>\';
		echo \'<tr>\';
		echo \'<th style="width: 10%">Name</th>\';
		echo \'<th style="width: 10%">Email</th>\';
		echo \'<th style="width: 65%">Details</th>\';
		echo \'<th style="width: 15%">CV</th>\';
		echo \'</tr>\';

		//prepare and execute a query to select the applicants from the database
		$stmt = $pdo->prepare(\'SELECT * FROM applicants WHERE jobId = :id\');
		$stmt->execute([\'id\' => $_GET[\'id\']]);

		foreach ($stmt as $applicant) {
			echo \'<tr>\';
			echo \'<td>\' . $applicant[\'name\'] . \'</td>\';
			echo \'<td>\' . $applicant[\'email\'] . \'</td>\';
			echo \'<td>\' . $applicant[\'details\'] . \'</td>\';
			//create a link to download the CV
			echo \'<td><a href="/cvs/\' . $applicant[\'cv\'] . \'">Download CV</a></td>\';
			echo \'</tr>\';
		}

		echo \'</thead>\';
		echo \'</table>\';

	}

	else {
		//require the login.php file
		require\'admin/login.php\';
	}
	?>
	</section>
	</main>';
	
	?>


<!--The code is PHP code that generates HTML content for a web page.

The first section starts a session and sets the title of the page to "Jo's Jobs - Applicants".
The second section defines a variable $content that contains the HTML code for the page.
The PHP code within $content includes two files: leftSectionBar.php and login.php.
The leftSectionBar.php file is included to generate a sidebar on the page.
The code then checks whether the user is logged in. If the user is logged in, the code retrieves the job details from the database, generates a table and displays the applicants' information including name, email, details and a link to download the CV. If the user is not logged in, the code includes login.php file, which displays a login form to allow the user to log in to view the page.
Overall, this code generates a page that displays information about applicants for a particular job, but only if the user is logged in.-->
<!--The code is PHP code that generates HTML content for a web page.

The first section starts a session and sets the title of the page to "Jo's Jobs - Applicants".
The second section defines a variable $content that contains the HTML code for the page.
The PHP code within $content includes two files: leftSectionBar.php and login.php.
The leftSectionBar.php file is included to generate a sidebar on the page.
The code then checks whether the user is logged in. If the user is logged in, the code retrieves the job details from the database, generates a table and displays the applicants' information including name, email, details and a link to download the CV. If the user is not logged in, the code includes login.php file, which displays a login form to allow the user to log in to view the page.
Overall, this code generates a page that displays information about applicants for a particular job, but only if the user is logged in.-->