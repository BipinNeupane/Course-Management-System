<?php
session_start();
error_reporting(0);
//variable to hold page's title
$title = "Jo's Jobs - Categories";

?>
<?php
$content = '<!-- main section of the page -->
	<main class="sidebar">
	<?php
	//requiring needed file
	require\'admin/leftSectionBar.php\';
	?>
	
<!-- right section of the main -->
	<section class="right">

	<?php
//condition to check if the user is logged in
		if (isset($_SESSION[\'loggedin\']) && $_SESSION[\'loggedin\'] == true) {
		?>

<!-- headline -->
			<h2>Categories</h2>
<!-- link -->
			<a class="new" href="index.php?page=admin/addcategory">Add new category</a>

			<?php
			// requiring needed file
			require \'admin/category-template.php\';
        }

		else {
			?>
		<?php
		//requiring needed file
		require \'admin/login.php\';
		}
	?>

</section>
	</main>';
?>


<!--This is a PHP code that generates the content of a page for managing job categories. The code starts with setting the page title variable, followed by defining the content of the page which includes a left section bar and a right section where the categories are displayed.

The left section bar is included by requiring a separate PHP file called "admin/leftSectionBar.php".

The right section is divided into two parts: the headline and a link to add a new category, and the category template which is also included by requiring another PHP file called "admin/category-template.php".

The code also checks whether the user is logged in before displaying the content. If the user is not logged in, the login form is required by including another PHP file called "admin/login.php".-->

<!--This is a PHP code that generates the content of a page for managing job categories. The code starts with setting the page title variable, followed by defining the content of the page which includes a left section bar and a right section where the categories are displayed.

The left section bar is included by requiring a separate PHP file called "admin/leftSectionBar.php".

The right section is divided into two parts: the headline and a link to add a new category, and the category template which is also included by requiring another PHP file called "admin/category-template.php".

The code also checks whether the user is logged in before displaying the content. If the user is not logged in, the login form is required by including another PHP file called "admin/login.php".-->