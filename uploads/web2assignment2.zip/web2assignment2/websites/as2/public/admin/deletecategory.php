<?php
session_start();
error_reporting(0);
ob_start();
//requiring needed page
require 'connection.php';
ob_end_clean();
//condition to check if is logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
    // preparing statement
	$stmt = $pdo->prepare('DELETE FROM category WHERE id = :id');
	// executing statement
	$stmt->execute(['id' => $_POST['id']]);

    //directing
	header('location:index.php?page=admin/categories');
	exit;
}


//This code snippet is a PHP script that deletes a category from the database table category when a user submits a form. It starts with the usual session handling code that checks if the user is logged in. If the user is logged in, it prepares an SQL statement to delete the category with the ID specified in the id field of the form that was submitted.

//The DELETE FROM category WHERE id = :id SQL statement deletes the row from the category table where the id column matches the id value submitted in the form. The :id placeholder is a named parameter that is bound to the id value submitted in the form using the execute() method of the PDOStatement object.

//Finally, the script redirects the user to the categories page using the header() function
//This code snippet is a PHP script that deletes a category from the database table category when a user submits a form. It starts with the usual session handling code that checks if the user is logged in. If the user is logged in, it prepares an SQL statement to delete the category with the ID specified in the id field of the form that was submitted.

//The DELETE FROM category WHERE id = :id SQL statement deletes the row from the category table where the id column matches the id value submitted in the form. The :id placeholder is a named parameter that is bound to the id value submitted in the form using the execute() method of the PDOStatement object.

//Finally, the script redirects the user to the categories page using the header() function