<?php
function selectFromTable($table, $columns = '*', $conditions = [], $orderBy = '', $limit = '') {
    global $pdo; 
    $query = "SELECT $columns FROM $table";
    if (!empty($conditions)) {
        $query .= " WHERE ";
        foreach ($conditions as $column => $value) {
            if(is_array($value)){
                $query .= "$column $value[0] :$column AND ";
            }else{
                $query .= "$column = :$column AND ";
            }
        }
        $query = rtrim($query, " AND "); // remove the last "AND" from the query
    }
    if(!empty($orderBy)){
        $query .= " ORDER BY $orderBy";
    }
    if(!empty($limit)){
        $query .= " LIMIT $limit";
    }
    $stmt = $pdo->prepare($query);
    if (!empty($conditions)) {
        foreach ($conditions as $column => $value) {
            if(is_array($value)){
                $stmt->bindValue(":$column", $value[1]);
            }else{
                $stmt->bindValue(":$column", $value);
            }
        }
    }
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

?>

<!--This is a PHP function that performs a SELECT query on a database table using PDO. It takes four parameters:

$table: the name of the table to query
$columns: the columns to select (default is '*')
$conditions: an associative array of conditions to add to the WHERE clause (default is an empty array)
$orderBy: the column(s) to order the results by (default is an empty string)
$limit: the maximum number of rows to return (default is an empty string)
The function first builds the SQL query string based on the parameters. If there are conditions specified, it adds them to the WHERE clause using prepared statements to avoid SQL injection. It then prepares and executes the query using PDO, and returns the result set as an associative array.-->
<!--This is a PHP function that performs a SELECT query on a database table using PDO. It takes four parameters:

$table: the name of the table to query
$columns: the columns to select (default is '*')
$conditions: an associative array of conditions to add to the WHERE clause (default is an empty array)
$orderBy: the column(s) to order the results by (default is an empty string)
$limit: the maximum number of rows to return (default is an empty string)
The function first builds the SQL query string based on the parameters. If there are conditions specified, it adds them to the WHERE clause using prepared statements to avoid SQL injection. It then prepares and executes the query using PDO, and returns the result set as an associative array.-->