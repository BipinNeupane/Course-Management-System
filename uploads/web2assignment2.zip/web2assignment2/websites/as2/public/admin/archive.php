<?php
session_start();
error_reporting(0);

//initiating a variable named title
$title = "Jo's Jobs - Job Archived list";

?><?php
	$content = '<main class="sidebar">
<!--section of left bar is included here to reduce repetitiveness of code-->
	<?php
	$act = \'index.php?page=admin/unarchiveJob\';
	$val = \'unarchive\';
	require\'admin/leftSectionBar.php\';
	?>
<!--right section-->
	<section class="right">

	<?php
        //condition to check if is logged in or not
		if (isset($_SESSION[\'loggedin\']) && $_SESSION[\'loggedin\'] == true) {
		?>

             <!-- headline -->
			<h2>Jobs</h2>
            <!-- link -->
			<a class="new" href="addjob.php">Add new job</a>
			<nav>
				<ul>
				<li>Select Category
					<?php
					//echoin form
				    echo \'<form>\';
					echo \'<ul>\';
					//querying sql statement
    $categories = $pdo->query(\'SELECT * FROM category\');
	//use of foreach loop to get data
    foreach ($categories as $category) {
		//echoing retrieved data
    echo \'<li><a href="index.php?page=admin/Jobs&catId=\'.$category[\'id\'].\'">\' . $category[\'name\'] . \'</a></li>\';
    }
    echo\'	</ul>\';
					echo\'</form>\';
							
					?>
					</ul>
			</nav>

			<?php
			//querying sql statement
			$stmt = $pdo->query(\'SELECT * FROM job WHERE status = 0\');
			//require\'jobs.php\';
            toDisplayJob($stmt,$act,$val);
}else{
	//requiring needed page
	require\'admin/login.php\';
}
			?>
			</section>
			</main>';?>
<!--This PHP code starts a session, suppresses error reporting, and initializes a variable called $title with the value "Jo's Jobs - Job Archived list".

Then, the variable $content is set to a string containing HTML and embedded PHP code. The HTML code includes a left section bar that is required from the file admin/leftSectionBar.php, and a right section that displays a list of archived jobs.

If the user is logged in, the list of archived jobs is obtained from the database using the SQL statement SELECT * FROM job WHERE status = 0. The function toDisplayJob() is then called to display the retrieved jobs. If the user is not logged in, the user is redirected to the login page using require'admin/login.php';-->
<!--This PHP code starts a session, suppresses error reporting, and initializes a variable called $title with the value "Jo's Jobs - Job Archived list".

Then, the variable $content is set to a string containing HTML and embedded PHP code. The HTML code includes a left section bar that is required from the file admin/leftSectionBar.php, and a right section that displays a list of archived jobs.

If the user is logged in, the list of archived jobs is obtained from the database using the SQL statement SELECT * FROM job WHERE status = 0. The function toDisplayJob() is then called to display the retrieved jobs. If the user is not logged in, the user is redirected to the login page using require'admin/login.php';-->