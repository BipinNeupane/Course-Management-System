<section class="left">
		<ul>
			<li><a href="index.php?page=admin/jobs">Jobs</a></li>
			<li><a href="index.php?page=admin/categories">Categories</a></li>
            <li><a href="index.php?page=admin/archive">Archive</a><li>
			<li><a href="index.php?page=admin/userAccount">Account</a><li>
			<li><a href="index.php?page=admin/enquiry">Enquiry</a><li>	
			<li><a href="index.php?page=admin/logout">Logout</a><li>
		</ul>
	</section>
	<!--This code snippet defines a section of the left sidebar for the admin area of a website. It includes a list of links to different pages of the admin area, including jobs, categories, archive, user account, and enquiries, as well as a link to logout.

The code is written in HTML and can be embedded into the main page HTML using PHP's include or require statement.-->
<!--This code snippet defines a section of the left sidebar for the admin area of a website. It includes a list of links to different pages of the admin area, including jobs, categories, archive, user account, and enquiries, as well as a link to logout.

The code is written in HTML and can be embedded into the main page HTML using PHP's include or require statement.-->