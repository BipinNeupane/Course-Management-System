<!--this page is for the header. we have seperated the header code from the other code as it is
frequently is used almost in all pages so instead of writing the code for multiple times we can just 
call the code in other page and use it-->
<!--this page mostly has the code provided by the  university -->
<?php
require'connection.php';
if(isset( $_GET['page'])){
	require $_GET['page'].'.php';
};
?>
<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="/styles.css"/>
        <!--different pages has different title so i have introduced a variable title which will have the name of the title of the page 
    so the title's name varies along with the pages-->
		<title><?php echo $title;?></title>
	</head>
	<body>
	<header>
		<section>
			<aside>
				<h3>Office Hours:</h3>
				<p>Mon-Fri: 09:00-17:30</p>
				<p>Sat: 09:00-17:00</p>
				<p>Sun: Closed</p>
			</aside>
			<h1>Jo's Jobs</h1>

		</section>
	</header>
	<nav>
		<ul>
			<li><a href="/index.php?page=indexContent">Home</a></li>
            <li>Jobs
				<ul>
				<li class="cat">Categories
					<section class="categoryList">
			<?php
			require'category-list-template.php';
			?>
			</section>
			</li>

			<li class="location">location
			<section class="locationList">
				<?php
				$stmt = $pdo->query('SELECT DISTINCT(location) FROM job ');
				$locations = $stmt->fetchAll();
				foreach($locations as $location){
					echo '<li><a style="color:white;" href="index.php?page=categoryJob&location='.$location['location'].'">' . $location['location'] . '</a></li>';
				}
				?>
</section>
</li>
</ul>
</li>
			<li><a href="/index.php?page=about">About Us</a></li>
			<li><a href="/index.php?page=contact">Contact Us</a></li>
			<li><a href="index.php?page=FAQs">FAQs</a></li>
            <li><a href="index.php?page=admin/index">Admin</a></li>
		</ul>

	</nav>
<img src="/images/randombanner.php"/>
<!--Looks good! You have separated the header code into a separate file and introduced a variable for the title so that it can vary according to the page. You have also added links to different pages in the navigation menu, including a link to the admin page. The location and category lists are also being displayed dynamically from the database. Overall, it seems like a well-structured and organized header code-->