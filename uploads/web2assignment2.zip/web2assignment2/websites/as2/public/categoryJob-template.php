
<!-- main section-->
<main class="sidebar">
   <!-- left section of the main -->

   <section class="left">
    
		<ul>
		<?php eval("?>".$c1);?>
		</ul>
	</section>
	
<!-- right section of the main-->
	<section class="right">
		<!-- condition to check whether catID is null or not -->
	<?php  eval("?>".$c2);?>

	<ul class="listing">
	<?php
	eval("?>".$c3);
 ?>

</ul>
</section>
	</main>

	<!--This is a PHP file that generates the main section of a webpage. It includes two sections: the left section and the right section.

The left section includes an unordered list of categories retrieved from a database using the category-list-template.php file.

The right section includes a header that displays the category name if the catId variable is not empty, and the location name if the location variable is not empty. It also includes an unordered list of jobs retrieved from the database using the job table and the categorisedJob-template.php file. The jobs are filtered based on the catId or location variable, and their status is set to 1 and their closing date is after the current date.

The eval() function is used to execute the PHP code stored in the variables $c1, $c2, and $c3, which are generated in the index.php file based on the catId and location variables received from the URL.

The main section is wrapped in a main element with a class of sidebar.-->

<!--This is a PHP file that generates the main section of a webpage. It includes two sections: the left section and the right section.

The left section includes an unordered list of categories retrieved from a database using the category-list-template.php file.

The right section includes a header that displays the category name if the catId variable is not empty, and the location name if the location variable is not empty. It also includes an unordered list of jobs retrieved from the database using the job table and the categorisedJob-template.php file. The jobs are filtered based on the catId or location variable, and their status is set to 1 and their closing date is after the current date.

The eval() function is used to execute the PHP code stored in the variables $c1, $c2, and $c3, which are generated in the index.php file based on the catId and location variables received from the URL.

The main section is wrapped in a main element with a class of sidebar.-->
