<?php
$title = "Jo's Jobs - Home";
$content = 
$content = 
'<main class="home">
<p>Welcome to Jo\'s Jobs, we\'re a recruitment agency based in Northampton. We offer a range of different office jobs. Get in touch if you\'d like to list a job with us.</a></p>
        <h2>Job closing soonest</h2>
		<?php
		$stmt = selectFromTable(\'job\', \'*\', [
			\'status\' => 1,
			\'closingDate\' => [\'>\', date(\'Y-m-d\')],
		], \'closingDate ASC\', 10);
		foreach($stmt as $jobAttribute){
			echo\'<li>\'.$jobAttribute[\'title\'].\'</br> closing date: \'.
			$jobAttribute[\'closingDate\'].\'</li>\';
		}
		?>
		<h2>Select the type of job you are looking for:</h2>
		<?php
		require \'admin/category-list-template.php\';
		?>
			</li>
            </main>';
?>
<!--This code sets two variables: $title and $content. $title contains a string with the title of the webpage. $content contains 
HTML markup, as well as two PHP blocks that use the  tags to execute code within the HTML.

The first PHP block queries a database table called 'job' using the 'selectFromTable()' function. It selects all columns from the 
table where the 'status' column is set to 1 and the 'closingDate' column is greater than the current date. The query results are then 
looped over using a foreach loop, and for each row, the 'title' and 'closingDate' columns are outputted as an HTML list item.

The second PHP block requires a file called 'category-list-template.php', which presumably contains a template for a list of job 
categories.

Overall, this code appears to be setting up the content of the home page for a recruitment agency website. The use of PHP to query a 
database and output dynamic content suggests that the website is likely to have functionality for job listings and searching.-->

<!--This code sets two variables: $title and $content. $title contains a string with the title of the webpage. $content contains 
HTML markup, as well as two PHP blocks that use the tags to execute code within the HTML.

The first PHP block queries a database table called 'job' using the 'selectFromTable()' function. It selects all columns from the 
table where the 'status' column is set to 1 and the 'closingDate' column is greater than the current date. The query results are then 
looped over using a foreach loop, and for each row, the 'title' and 'closingDate' columns are outputted as an HTML list item.

The second PHP block requires a file called 'category-list-template.php', which presumably contains a template for a list of job 
categories.

Overall, this code appears to be setting up the content of the home page for a recruitment agency website. The use of PHP to query a 
database and output dynamic content suggests that the website is likely to have functionality for job listings and searching.-->
