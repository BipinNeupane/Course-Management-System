 <!-- apply page -->
			<!-- title -->
			<h2>Apply for <?=$job['title'];?></h2>
<form action="index.php?page=apply" method="POST" enctype="multipart/form-data">
				<!-- labelling -->
				<label>Your name</label>
				<!-- input with text type -->
				<input type="text" name="name" />
                <!-- labelling -->
				<label>E-mail address</label>
				<!-- input with text type -->
				<input type="text" name="email" />
                <!-- labelling -->
				<label>Cover letter</label>
				<!-- input text area-->
				<textarea name="details"></textarea>
                <!-- labelling -->
				<label>CV</label>
				<!-- input file type -->
				<input type="file" name="cv" />
               <!-- input hidden type -->
				<input type="hidden" name="jobId" value="<?=$iid;?>" />
               <!-- input submit type -->
				<input type="submit" name="submit" value="Apply" />

			</form>
			<!--This is the HTML code for the application form on the "Apply" page. The form has several input fields that allow the user to submit their job application, including their name, email, cover letter, and CV. The input field for the CV file is of type "file", which allows the user to select a file from their computer.

The form action is set to "index.php?page=apply", which means that when the form is submitted, the data will be sent to the "apply" page of the website.

There is also a hidden input field called "jobId", which is used to store the ID of the job that the user is applying for. This value is set to the PHP variable "$iid", which is defined earlier in the code.

Finally, there is a submit button with the label "Apply". When the user clicks this button, the form data will be submitted to the server for processing.





Regenerate response-->
<!--This is the HTML code for the application form on the "Apply" page. The form has several input fields that allow the user to submit their job application, including their name, email, cover letter, and CV. The input field for the CV file is of type "file", which allows the user to select a file from their computer.

The form action is set to "index.php?page=apply", which means that when the form is submitted, the data will be sent to the "apply" page of the website.

There is also a hidden input field called "jobId", which is used to store the ID of the job that the user is applying for. This value is set to the PHP variable "$iid", which is defined earlier in the code.

Finally, there is a submit button with the label "Apply". When the user clicks this button, the form data will be submitted to the server for processing.





Regenerate response-->
