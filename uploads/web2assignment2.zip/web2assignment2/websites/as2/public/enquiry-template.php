    <!-- use of form-->
<form action="" method="post">
 <!--labelling -->
  <label for="email">Email:</label>
  <!-- input with email type -->
  <input type="email" id="email" name="email" ><br>
<!-- labelling -->
  <label for="enquiry">Enquiry:</label>
  <!-- input with text area type -->
  <textarea id="enquiry" name="enquiry" ></textarea><br>
  <!-- input of hidden type -->
  <input type="submit" value="Submit" name="submit">
</form>
<!--This is an HTML form that allows a user to submit an enquiry. It has two input fields:

Email: This is an email input field where the user enters their email address.
Enquiry: This is a text area input field where the user can enter their enquiry.
There is also a submit button that the user can click to submit the form. When the user submits the form, the data is sent to the server using the HTTP POST method.

The form does not have an action attribute specified, which means that it will submit the data to the current URL. The PHP code that handles the form submission should be placed at the top of the current page or in a separate file that is included at the top of the page-->
<!--This is an HTML form that allows a user to submit an enquiry. It has two input fields:

Email: This is an email input field where the user enters their email address.
Enquiry: This is a text area input field where the user can enter their enquiry.
There is also a submit button that the user can click to submit the form. When the user submits the form, the data is sent to the server using the HTTP POST method.

The form does not have an action attribute specified, which means that it will submit the data to the current URL. The PHP code that handles the form submission should be placed at the top of the current page or in a separate file that is included at the top of the page-->
